const express = require("express");
const cookieParser = require("cookie-parser");
const bodyParser = require("body-parser");
const sessions = require("express-session");
const { render } = require("ejs");
const app = express();
const PORT = 3000;
const oneDay = 1000 * 60 * 60 * 24;//milissegundos
const client = require("./db");

const db = client.db("ssvp");
const doacaocollection = db.collection("doacao");

app.use(sessions({
    secret: "thisismysecretkeyfhrg84",
    saveUninitialized: true,
    cookie: { maxAge: oneDay },
    resave: false
}));

app.use(express.json());

app.use(express.urlencoded({
    extended: true
}));

app.use(express.static(__dirname));

app.use(cookieParser());

app.use(bodyParser.urlencoded({
    extended: false
}));

app.use(bodyParser.json());

const email = "cz.paiva08@gmail.com";
const inputPassword2 = "123";

var session;

app.set("view engine", "ejs");

app.get("/", function (req, res) {
    session = req.session;
    if (session.userid) {
        res.send("Bem vindo a página da SSVP de Porto Seguro!! <a href = \'/logout'> clique para logar </a>");
    }
    else {
        res.render("home");
    }
});

app.post("/cadastrodoacao", function (req, res) {
    if (req.body.email == "cz.paiva08@gmail.com" && req.body.inputPassword2 == "123") {
        session = req.session;
        session.userid = req.body.email;
        console.log(req.session);
        res.render("cadastrodoacao");
    }
    else {
        res.send("nome ou senha invalida");
    }
});

app.post("/listadoacoes", (req, res) => {
doacaocollection.insertOne(req.body).then(result => {
    console.log(result)
    console.log(req.body)
})
.catch(error => console.error(error))
});

app.get("/logout", function (req, res) {
    req.session.destroy()
    res.redirect("/")
});

app.listen(PORT, function () {
    console.log(" servidor rodando na porta", { PORT })
});



